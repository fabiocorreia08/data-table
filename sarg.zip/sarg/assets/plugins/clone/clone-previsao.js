$(function () {
    $('#btnAdd').hide().click(function () {
        var num     = $('.clonePrevisao').length, // Checks to see how many "duplicatable" input fields we currently have
            newNum  = new Number(num + 1),      // The numeric ID of the new input field being added, increasing by 1 each time
            newElem = $('#previsao' + num).clone().attr('id', 'previsao' + newNum).fadeIn('fast'); // create the new element via clone(), and manipulate it's ID using newNum value

        // H2 - Número Previsão
        newElem.find('.heading-reference').attr('id', 'ID' + newNum + '_reference').attr('name', 'ID' + newNum + '_reference').html('<b>Previsão 0' + newNum + '</b><small>/04</small>');

    // Insert the new element after the last "duplicatable" input field
    $('#previsao' + num).after(newElem);
    $('#ID' + newNum + '_title').focus();

    // Enable the "remove" button. This only shows once you have a duplicated section.
    $('#btnDel').show();//.attr('disabled', false);

    // Right now you can only add 4 sections, for a total of 5. Change '5' below to the max number of sections you want to allow.
    if (newNum == 4) 
        $('#btnAdd').attr('disabled', true).text("Limite máximo de previsões");
    $('#btnDel').attr('disabled', false);

});

    $('#btnDel').click(function () {
        if (this)
        {
            var num = $('.clonePrevisao').length;
                // how many "duplicatable" input fields we currently have
                $('#previsao' + num).slideUp('slow', function () {
                    $(this).remove();
                    $('#btnDel').show().attr('disabled', false);//.hide();
                // if only one element remains, disable the "remove" button
                if (num -1 === 1)
                    $('#btnDel').hide().attr('disabled', true);
                // enable the "add" button
                $('#btnAdd').show().attr('disabled', false).html("<i class='fa fa-plus' aria-hidden='true'></i> Adicionar Novo");
            });
            }
        return false; // Removes the last section you added
    });
    // Enable the "add" button
    $('#btnAdd').show();//.attr('disabled', false);
    // Disable the "remove" button
    $('#btnDel').hide();//.attr('disabled', true);
});